package com.example.city;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button xmlparse,json;

        xmlparse=findViewById(R.id.parseXML);
        json=findViewById(R.id.parseJSON);
        json.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String json_city = getListData();

                try {

                    ArrayList<HashMap<String, String>> userList = new ArrayList<>();
                    ListView listview = findViewById(R.id.cityData);

                    JSONObject jsObj = new JSONObject(json_city);
                    JSONArray jsArray = jsObj.getJSONArray("CityDetails");
                    for (int i = 0; i < jsArray.length(); i++) {
                        HashMap<String, String> city = new HashMap<>();
                        JSONObject obj = jsArray.getJSONObject(i);
                        city.put("City_Name",  obj.getString("City_Name"));
                        city.put("Latitude", obj.getString("Latitude"));
                        city.put("Longitude", obj.getString("Longitude"));
                        city.put("Temperature", obj.getString("Temperature"));
                        city.put("Humidity", obj.getString("Humidity"));
                        userList.add(city);
                    }
                    findViewById(R.id.parseJSON).setVisibility(View.GONE);
                    findViewById(R.id.resultJSON).setVisibility(View.VISIBLE);
                    ListAdapter simpleAdapter = new SimpleAdapter(getApplicationContext(), userList, R.layout.list, new String[]{"City_Name", "Latitude", "Longitude","Temperature","Humidity"}, new int[]{R.id.City_Name, R.id.JSON_latitude, R.id.JSON_longitude,R.id.JSON_temperature,R.id.JSON_humidity});
                    listview.setAdapter(simpleAdapter);

                } catch (JSONException ex) {
                    Log.e("JsonParser ", "Exception", ex);
                }
            }


            public String getListData() {
                String jsonString = null;
                try {
                    AssetManager manager = getApplicationContext().getAssets();
                    InputStream is = manager.open("citydata.json");
                    int size = is.available();
                    byte[] buffer = new byte[size];
                    is.read(buffer);
                    is.close();
                    jsonString = new String(buffer, "UTF-8");
                    //return new String(buffer, "UTF-8");

                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("JSONPARSER", "Failed to read asset file: ", e);
                    return null;
                }
                return  jsonString;
            }
        });
        xmlparse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                TextView tv1=(TextView)findViewById(R.id.textview1);

                try {
                    InputStream is = getAssets().open("city.xml");

                    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                    Document doc = dBuilder.parse(is);

                    Element element=doc.getDocumentElement();
                    element.normalize();

                    NodeList nList = doc.getElementsByTagName("CityDetails");

                    for (int i=0; i<nList.getLength(); i++) {

                        Node node = nList.item(i);
                        if (node.getNodeType() == Node.ELEMENT_NODE) {
                            Element element2 = (Element) node;
                            tv1.setText(tv1.getText()+"\nCity_name : " + getValue("City_name", element2)+"\n");
                            tv1.setText(tv1.getText()+"Latitude : "+ getValue("Latitude", element2)+"\n");
                            tv1.setText(tv1.getText()+"Longitude : " + getValue("Longitude", element2)+"\n");
                            tv1.setText(tv1.getText()+"Temperature : " + getValue("Temperature", element2)+"\n");
                            tv1.setText(tv1.getText()+"Humidity : " + getValue("Humidity", element2)+"\n");
                            tv1.setText(tv1.getText()+"-------------------------------------------------");
                        }
                    }
                    findViewById(R.id.parseXML).setVisibility(View.GONE);
                    findViewById(R.id.resultXML).setVisibility(View.VISIBLE);
                } catch (Exception e) {e.printStackTrace();}
            }
            private  String getValue(String tag, Element element) {
                NodeList nodeList = element.getElementsByTagName(tag).item(0).getChildNodes();
                Node node = nodeList.item(0);
                return node.getNodeValue();
            }

        });

    }
}